import numpy as np
from pylab import *
import matplotlib.pyplot as plt
import cv2
A=cv2.imread("x-ray_in.jpg",0)
a=A.shape[0]
c=A.shape[1]
b=3
C=np.zeros((a+b-1,c+b-1))
D=np.zeros((a+b-1,c+b-1))
def mean(img,kernel_size):
	newimg=np.zeros((a,c))
	for i in range(a):
		for j in range(c):
			val=0
			for p in range(kernel_size):
				for q in range(kernel_size):
					if i+p<a and i+p>=0 and j+q<c and j+q>=0:
						val+=img[i+p][j+q]
			newimg[i][j] = val/np.square(kernel_size)
#	subplot(121)
#	plt.imshow(newimg,cmap='gray'),plt.title("Mean filter"),plt.xticks([]),plt.yticks([])
#	plt.show()
	return newimg
def laplace(A):
	B=[[0,-1,0],[-1,4,-1],[0,-1,0]]
	for i in range(a+b-1):
		for j in range(a+b-1):
			l1min=max(i-b+1,0)
			l1max=min(i,a-1)
			l2min=max(j-b+1,0)
			l2max=min(j,c-1)
			for k in range(l1min,l1max+1):
				for l in range(l2min,l2max+1):
					C[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]
#	subplot(121)
#	plt.imshow(A,cmap='gray'),plt.title("image"),plt.xticks([]),plt.yticks([])
#	subplot(122)
#	plt.imshow(C,cmap='gray'),plt.title("Laplace filter"),plt.xticks([]),plt.yticks([])
#	plt.show()
#	cv2.imwrite("laplace.jpg",C)
	return C
def sobel(A):
	B=[[1,2,1],[0,0,0,],[-1,-2,-1]]
	for i in range(a+b-1):
		for j in range(a+b-1):
			l1min=max(i-b+1,0)
			l1max=min(i,a-1)
			l2min=max(j-b+1,0)
			l2max=min(j,c-1)
			for k in range(l1min,l1max+1):
				for l in range(l2min,l2max+1):
					C[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]

	B=[[-1,0,1],[-2,0,2],[-1,0,1]]
	for i in range(a+b-1):
		for j in range(a+b-1):
			l1min=max(i-b+1,0)
			l1max=min(i,a-1)
			l2min=max(j-b+1,0)
			l2max=min(j,c-1)
			for k in range(l1min,l1max+1):
				for l in range(l2min,l2max+1):
					D[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]
	subplot(121)
#	plt.imshow(np.sqrt(np.square(C)+np.square(D)),cmap='gray'),plt.title("Sobel filter"),plt.xticks([]),plt.yticks([])
#	plt.show()
#	cv2.imwrite("sobel.jpg",np.sqrt(np.square(C)+np.square(D)))
	return np.sqrt(np.square(C)+np.square(D))
A=mean(A,kernel_size=3)
new_image1=sobel(A)
new_image1=cv2.resize(new_image1,(A.shape[1],A.shape[0]))
new_image1=mean(new_image1,kernel_size=3)
cv2.imwrite("sobel.jpg",new_image1)
new_image2=laplace(A)
new_image2=cv2.resize(new_image2,(A.shape[1],A.shape[0]))
cv2.imwrite("laplace.jpg",new_image2)
k = 0.9
gamma= 1.00001
new_image= k*np.power(new_image1+new_image2+A,gamma)
cv2.imwrite("2.jpg",new_image)

