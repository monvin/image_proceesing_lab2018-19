# import the necessary packages
import numpy as np
from PIL import Image
import cv2

def find_filter_median(p2n,p1MASK):


	im = cv2.imread("result.jpg",0)
	a = np.array(im)
	
	r = a.shape[0]

	c = a.shape[1]
	
	result_median = a
	
	h = 0
	w = 0

#Code for convolution

	for i in range(p2n//2,r-p2n//2):
		for j in range(p2n//2,c-p2n//2):
			s=np.zeros((p2n*p2n,1),dtype = int)
			k=0
			for p in range(p2n):
				for q in range(p2n):
					if(i+p-h<r and i+p-h>=0 and j+q-w<c and j+q-w>=0):
						s[k][0] = p1MASK[p2n-1-p][p2n-1-q]*a[i+p-h][j+q-w]
						k+=1
			result_median[i][j] = np.median(s)
	cv2.imwrite("result.jpg",result_median)

	return

img = cv2.imread('blob.jpg',0)

img = cv2.medianBlur(img,11)

cimg = cv2.cvtColor(img,cv2.COLOR_GRAY2BGR)

circles = cv2.HoughCircles(img,cv2.HOUGH_GRADIENT,1,20,param1=50,param2=30,minRadius=30,maxRadius=50)

circles = np.uint16(np.around(circles))

for i in circles[0,:]:
    cv2.circle(cimg,(i[0],i[1]),i[2],(255,0,0),2)
    

circles = cv2.HoughCircles(img,cv2.HOUGH_GRADIENT,1,20,param1=50,param2=30,minRadius=10,maxRadius=25)

circles= np.uint16(np.around(circles))

for i in circles[0,:]:
    cv2.circle(cimg,(i[0],i[1]),i[2],(0,0,255),2)

cv2.imwrite("Separated.jpg",cimg)

im = Image.open("Separated.jpg")

im.show()
