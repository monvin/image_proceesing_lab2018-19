import numpy as np
import cv2
from pylab import *
img=cv2.imread("blob.jpg",0)
G=np.zeros(img.shape)
print(img)
n=img.shape[0]
T=10
T_=255
while np.abs(T-T_)>1:
	print("rr")
	T=T_
	A1=0
	A2=0
	for i in range(n):
		for j in range(n):
			if img[i][j]>T:
				G[i][j]=1
				A1+=img[i][j]

			else:
				G[i][j]=0
				A2+=img[i][j]
	print(G)
	A1=np.average(img*G)			
	A2=np.average(img*(1-G))
	T_=(A1+A2)/2
	print(T)
	print(T_)
subplot(121)
plt.imshow(img*G,cmap='gray'),plt.title('ddd'),plt.xticks([]), plt.yticks([])
cv2.imwrite("test.jpg",img*G)
subplot(122)
plt.imshow(img*(1-G),cmap='gray'),plt.title('ddd'),plt.xticks([]), plt.yticks([])
cv2.imwrite("test1.jpg",img*(1-G))
plt.show()
