import cv2 
import numpy as np
from matplotlib import pyplot as plt 

image = cv2.imread("blob.jpg",0)
height, width = image.shape[:2]

median = cv2.medianBlur(image,3)
cimg = cv2.cvtColor(median,cv2.COLOR_GRAY2BGR)
circles = cv2.HoughCircles(median,cv2.HOUGH_GRADIENT,1,20,param1=50,param2=30,minRadius=30,maxRadius=50)
circles = np.uint16(np.around(circles))
for i in circles[0,:]:
	cv2.circle(cimg,(i[0],i[1]),i[2],(0,255,0),-1)
	cv2.circle(cimg,(i[0],i[1]),2,(0,255,0),3)

circles = np.uint16(np.around(circles))
for i in circles[0,:]:
	cv2.circle(cimg,(i[0],i[1]),i[2],(0,0,255),-1)
	cv2.circle(cimg,(i[0],i[1]),2,(0,0,255),3)


cv2.imwrite("2.jpg",cimg)
