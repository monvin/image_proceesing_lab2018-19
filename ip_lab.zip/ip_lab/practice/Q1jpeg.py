import numpy as np
import cv2
from pylab import *
import collections
img=cv2.imread("cameraman.tif",0)
def dct(img):
	T=np.zeros(img.shape)
	n=img.shape[0]
	for u in range(n):
		for x in range(n):
			if u==0:
				T[u][x]=np.sqrt(1/n)*(np.cos((2*x+1)*np.pi*u/(2*n)))
			else:
				T[u][x]=np.sqrt(2/n)*(np.cos((2*x+1)*np.pi*u/(2*n)))
	DCT=np.dot(np.dot(T,img),np.transpose(T))
	return DCT	
def qtn_mat(img):
	Q=np.zeros(img.shape)
	for u in range(img.shape[0]):
		for v in range(img.shape[1]):
			Q[u][v]=1+u+v
	return Q
def flatten(x):
    if isinstance(x, collections.Iterable):
        return [a for i in x for a in flatten(i)]
    else:
        return [x]
def zigzag(img):
	rows=img.shape[0]
	columns=img.shape[1]
	solution=[[] for i in range(rows+columns-1)] 
	for i in range(rows): 
		for j in range(columns):
			sum=i+j 
			if(sum%2 ==0): 
				solution[sum].insert(0,img[i][j]) 
			else: 
				solution[sum].append(img[i][j]) 
	return flatten(solution)
def huffman(lis):
	huffman_encoding=[]
	count=1
	for i in range(1,len(lis)):
		if lis[i]==lis[i-1] :
			count+=1
		else:
			huffman_encoding.append(lis[i-1])
			huffman_encoding.append(count)
			count=1
	huffman_encoding.append(lis[i])
	huffman_encoding.append(count)
	print(huffman_encoding)
		
def jpegcompression(img):
	DCT=dct(img)
	qtn=qtn_mat(img)
	solution=zigzag(np.divide(np.abs(DCT),qtn))
	solution=np.array(solution)
	print(len(solution))
	huffman(solution.astype(int))
jpegcompression(img)
print(len(img))
