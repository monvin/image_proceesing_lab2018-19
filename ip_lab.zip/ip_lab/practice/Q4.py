import numpy as np
import cv2
from pylab import *
img=cv2.imread("x-ray_in.jpg",0)
newimg=np.zeros(img.shape)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]>127:
			newimg[i][j]=255
		else:
			newimg[i][j]=0
cv2.imwrite("8bit.jpg",newimg)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]>63 and img[i][j]<128:
			newimg[i][j]=255
		else:
			newimg[i][j]=0
cv2.imwrite("7bit.jpg",newimg)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]>31 and img[i][j]<64:
			newimg[i][j]=255
		else:
			newimg[i][j]=0
cv2.imwrite("6bit.jpg",newimg)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]>15 and img[i][j]<32:
			newimg[i][j]=255
		else:
			newimg[i][j]=0
cv2.imwrite("5bit.jpg",newimg)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]>7 and img[i][j]<16:
			newimg[i][j]=255
		else:
			newimg[i][j]=0
cv2.imwrite("4bit.jpg",newimg)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]>3 and img[i][j]<8:
			newimg[i][j]=255
		else:
			newimg[i][j]=0
cv2.imwrite("3bit.jpg",newimg)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]>1 and img[i][j]<4:
			newimg[i][j]=255
		else:
			newimg[i][j]=0
cv2.imwrite("2bit.jpg",newimg)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]<2:
			newimg[i][j]=255
		else:
			newimg[i][j]=0
cv2.imwrite("1bit.jpg",newimg)
