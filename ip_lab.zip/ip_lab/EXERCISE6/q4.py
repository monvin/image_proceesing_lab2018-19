import cv2 
import numpy as np
import matplotlib.pyplot as plt

image = cv2.imread("128.jpg",0)
height, width = image.shape[:2]

'''def corelation (matrixC,matrixB,n,m):
    matrixE = []
    matrixA = []

    if(m%2==1):
        for i in range(0,n+m-1):
            matrixA.append([])
            for j in range(0,n+m-1):
                if (i<m/2 or j<m/2 or i>(n-1+m/2) or j>(n-1+m/2)):
                    matrixA[i].append(0)
                else:
                    x=matrixC[i-m//2][j-m//2]
                    matrixA[i].append(x)
    

        for i in range(0,n):
            matrixE.append([])
            for j in range(0,n):
                sum=0
                for k in range(0,m):
                    for l in range(0,m):
                        sum=sum+matrixA[i+k][j+l]*matrixB[k][l]
                matrixE[i].append(sum)

        return matrixE'''

'''newimage = np.zeros((height,width),dtype=int)
matrixX = [[-1,-2,-1],[0,0,0],[1,2,1]]
matrixY = [[-1,0,1],[-2,0,2],[-1,0,1]] 
gx = corelation(image,matrixX,height,3)
gy = corelation(image,matrixY,height,3)
for i in range(height):
	for j in range(width):
		newimage[i][j] = np.sqrt(np.power(gx[i][j],2) + np.power(gy[i][j],2))'''


 
newimage_3 = cv2.Canny(image,50,150,apertureSize = 3)

'''newimage_2 = np.zeros((height,width),dtype=int)
for i in range(height):
	for j in range(width):
		if(newimage_3[i][j]>200):
			newimage_2[i][j] = 255
		else:
			newimage_2[i][j] = 0'''



array = []
k = 0
for i in range(height):
	print(i)
	for j in range(width):
		if(newimage_3[i][j] == 255):
			flag = 0
			p = i*np.cos(0)+j*np.sin(0)
			if(i==0 and j==0):
				array.append([])
				array[k].append(0)
				array[k].append(p)
				array[k].append(1)
				#print(array[k])
				#print(k)
				k = k + 1
			else:
				for x in range(k):
					if(array[x][0] == 0 and array[x][1] == p):
						array[x][2] = array[x][2] + 1
						#print(array[x])
						#print(k)
						flag = 1
				if(flag == 0):
					array.append([])
					array[k].append(0)
					array[k].append(p)
					array[k].append(1)
					#print(array[k])
					#print(k)
					k = k + 1

			flag = 0
			p = i*np.cos(-np.pi/4)+j*np.sin(-np.pi/4)
			for x in range(k):
				if(array[x][0] == -45 and array[x][1] == p):
					array[x][2] = array[x][2] + 1
					#print(array[x])
					#print(x)
					flag = 1
			if(flag == 0):
				array.append([])
				array[k].append(-45)
				array[k].append(p)
				array[k].append(1)
				#print(array[k])
				#print(k)
				k = k + 1

			flag = 0
			p = i*np.cos(np.pi/4)+j*np.sin(np.pi/4)
			for x in range(k):
				#print(x)
				if(array[x][0] == 45 and array[x][1] == p):
					array[x][2] = array[x][2] + 1
					#print(array[x])
					flag = 1
			if(flag == 0):
				array.append([])
				array[k].append(45)
				array[k].append(p)
				array[k].append(1)
				#print(array[k])
				k = k + 1
			flag = 0
			p = i*np.cos(np.pi/2)+j*np.sin(np.pi/2)
			for x in range(k):
				if(array[x][0] == 90 and array[x][1] == p):
					array[x][2] = array[x][2] + 1
					#print(array[x])
					flag = 1
			if(flag == 0):
				array.append([])
				array[k].append(90)
				array[k].append(p)
				array[k].append(1)
				#print(array[k])
				k = k + 1

maxi = 0
for i in range(k):
	if(array[i][2]>maxi):
		maxi = array[i][2]
print("maxi=",maxi)
max_count = 0
for i in range(k):
	if(maxi == array[i][2]):
		max_count = max_count + 1

theta = np.zeros(max_count)
r = np.zeros(max_count)
y = 0
for i in range(k):
	if(maxi == array[i][2]):
		if(array[i][0] == 0):
			theta[y] = 0
		elif(array[i][0] == -45):
			theta[y] = -np.pi/4
		elif(array[i][0] == 45):
			theta[y] = np.pi/4
		else:
			theta[y] = np.pi/2
		r[y] = array[i][1]
		y = y + 1

for i in range(y):
	print(r[i])
	print(theta[i])




for i in range(y):
	a = np.cos(theta[i])
	b = np.sin(theta[i])
	x0 = a*r[i]
	y0 = b*r[i]
	x1 = int(x0 + 1000*(-b))
	y1 = int(y0 + 1000*(a))
	x2 = int(x0 - 1000*(-b))
	y2 = int(y0 - 1000*(a))

	cv2.line(image,(x1,y1),(x2,y2),(0,0,255),2)


cv2.imwrite("4.jpg",image)

