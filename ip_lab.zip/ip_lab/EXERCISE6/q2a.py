import numpy as np
import cv2
import matplotlib.pyplot as plt
from pylab import *
img=cv2.imread("cameraman.tif",0)
n=img.shape[0]
def median(img,kernel_size):
	
	newimg=np.zeros((n,n))
	for i in range(n):
		for j in range(n):
			val=[]
			for p in range(kernel_size):
				for q in range(kernel_size):
					if i+p<n and i+p>=0 and j+q<n and j+q>=0:
						val.append(img[i+p][j+q])
			newimg[i][j] = np.median(val)
	subplot(121)
	plt.imshow(newimg,cmap='gray'),plt.title("Blurred Image"),plt.xticks([]),plt.yticks([])
	plt.show()
	return newimg

blurr=median(img,3)
mask=img-blurr
subplot(121)
plt.imshow(mask,cmap='gray'),plt.title("mask"),plt.xticks([]),plt.yticks([])
subplot(122)
newimg=img+mask*2
plt.imshow(newimg,cmap='gray'),plt.title("high boost filtering"),plt.xticks([]),plt.yticks([])
plt.show()
