import numpy as np
import cv2
from pylab import *
img=cv2.imread("cameraman.tif",0)
n=img.shape[0]
cutoff=int(input("cutoff:"))
d_u_v=np.zeros(img.shape)
T_U_X=np.zeros(img.shape,dtype=complex)
new_img=np.zeros(img.shape,dtype=complex)
#multiplication by -1^(x+y)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		new_img[i][j]=img[i][j]*np.power(-1,i+j)
for u in range(n):
	for x in range(n):
		T_U_X[u][x]=1/np.sqrt(n)*(np.cos(-2/n*np.pi*u*x)+1j*np.sin(-2/n*np.pi*u*x))
fourier=np.dot(T_U_X,np.dot(new_img,T_U_X))
#determining D
for i in range(n):
	for j in range(n):
		d_u_v[i][j]=np.sqrt(np.square(i-n/2)+np.square(j-n/2))
def HFE(d_u_v,cutoff):
	H=1-np.exp(-np.power(d_u_v,2)/(2*np.power(cutoff,2)))
	H=.5+.75*H
	return H
T_U_X_conj=np.conjugate(T_U_X)
F=np.multiply(HFE(d_u_v,cutoff),fourier)
final=np.abs(np.dot(T_U_X_conj,(np.dot(F,T_U_X_conj))))
for i in range(n):
	for j in range(n):
		new_img[i][j]=final[i][j]*np.power(-1,i+j)
cv2.imwrite("FF.jpg",np.real(new_img))
