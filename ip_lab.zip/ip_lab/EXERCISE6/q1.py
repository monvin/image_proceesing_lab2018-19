import numpy as np
import cv2
from pylab import *
img=cv2.imread("cameraman.tif",0)
n=img.shape[0]
d_u_v=np.zeros(img.shape)
T_U_X=np.zeros(img.shape,dtype=complex)
new_img=np.zeros(img.shape,dtype=complex)
#multiplication by -1^(x+y)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		new_img[i][j]=img[i][j]*np.power(-1,i+j)
for u in range(n):
	for x in range(n):
		T_U_X[u][x]=1/np.sqrt(n)*(np.cos(-2/n*np.pi*u*x)+1j*np.sin(-2/n*np.pi*u*x))
fourier=np.dot(T_U_X,np.dot(new_img,T_U_X))
#determining D
for i in range(n):
	for j in range(n):
		d_u_v[i][j]=np.sqrt(np.square(i-n/2)+np.square(j-n/2))
#MAIN MENU
while True:
	cutoff=int(input("cutoff:"))
	def high():
		H=d_u_v>cutoff
		return H,"high pass"
	def butter():
		H=1-1/(1+(d_u_v/cutoff)**(2*n))
		return H,"butterworth"
	def gauss():
		H=1-np.exp(-np.power(d_u_v,2)/(2*np.power(cutoff,2)))
		return H,"gaussian"
	choice=int(input("1.high pass filter\n2.Butterworth\n3.Gaussian\n"))
	if choice==1:
		H,ftr=high()
	elif choice==2:
		H,ftr=butter()
	else:
		H,ftr=gauss()
	T_U_X_conj=np.conjugate(T_U_X)
	#multiplication by -1^(x+y)
	F=np.multiply(H,fourier)
	final=np.real(np.dot(T_U_X_conj,(np.dot(F,T_U_X_conj))))
	for i in range(n):
		for j in range(n):
			new_img[i][j]=final[i][j]*np.power(-1,i+j)
	subplot(121)
	plt.imshow(np.real(new_img),cmap='gray'),plt.title(ftr+" filter"),plt.xticks([]),plt.yticks([])
	cv2.imwrite("7_"+ftr+".jpg",np.real(new_img))
	plt.show()
