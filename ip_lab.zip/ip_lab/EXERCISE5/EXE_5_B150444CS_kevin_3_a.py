import numpy as np
import cv2
import matplotlib.pyplot as plt
from pylab import *
img=cv2.imread("cameraman.tif",0)
histogram=np.ndarray.flatten(img)
plt.xlabel("pixel intensity")
plt.ylabel("frequency")
plt.xlim(left=0, right = 255)
plt.hist(histogram,255,rwidth=.95)
savefig("3_a.jpg")
plt.show()

