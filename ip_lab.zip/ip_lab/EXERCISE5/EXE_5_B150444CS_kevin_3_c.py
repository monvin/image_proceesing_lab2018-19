import numpy as np
import cv2
import matplotlib.pyplot as plt
from pylab import *
img=cv2.imread("q3.jpg",0)
n=img.shape[0]
hist_img=np.zeros((256,))
for i in range(n):
	for j in range(n):
		hist_img[img[i][j]]+=1
histogram=np.ndarray.flatten(img)
plt.xlabel("pixel intensity")
plt.ylabel("frequency")
plt.xlim(left=0, right = 255)
plt.hist(histogram)
plt.show()
for i in range(1,256):
	hist_img[i]+=hist_img[i-1]
hist_img=(hist_img/(n*n))*255
x=[x for x in range(0,256)]
plt.xlabel("pixel intensity")
plt.ylabel("histogram equalized pixel intensity")
plt.xlim(left=0, right = 256)
plt.bar(x,hist_img,align='center',width=1)
plt.show()
for i in range(n):
	for j in range(n):
		img[i][j]=hist_img[img[i][j]]
plt.imshow(img,cmap='gray'),plt.title('HIstogram Equalized Image'),plt.xticks([]), plt.yticks([])
hist=cv2.equalizeHist(img)
cv2.imwrite("hih.jpg",hist)
savefig("3_c.jpg")
plt.show()

