import numpy as np
import cv2
import matplotlib.pyplot as plt
from pylab import *
variance=.02
mean=0
img=cv2.imread("cameraman.tif",0)
n=img.shape[0]
subplot(121)
plt.imshow(img),plt.title("Input image"),plt.xticks([]),plt.yticks([])
img=img+np.random.normal(mean,np.sqrt(variance),img.shape)*100
subplot(122)
plt.imshow(img,cmap='gray'),plt.title("Output image"),plt.xticks([]),plt.yticks([])
plt.show()
cv2.imwrite("2_b.jpg",img)
