import numpy as np
import cv2
import matplotlib.pyplot as plt
from pylab import *
variance=.1
mean=0
img=cv2.imread("cameraman.tif")
n=img.shape[0]
subplot(121)
plt.imshow(img),plt.title("Input image"),plt.xticks([]),plt.yticks([])
for i in range(n):
	for j in range(n):
		img[i][j]=(img[i][j]-mean)/np.sqrt(variance)
subplot(122)
plt.imshow(img),plt.title("Output image"),plt.xticks([]),plt.yticks([])
plt.show()
cv2.imwrite("2_d.jpg",img)
