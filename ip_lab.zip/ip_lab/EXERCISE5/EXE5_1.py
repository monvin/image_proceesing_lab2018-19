import numpy as np 

from PIL import Image

from matplotlib import pyplot as plt

import cv2

im = Image.open("q1.tif")

a = np.array(im)

r = a.shape[0]

c = a.shape[1]

transform_g = np.zeros((r,c),dtype = np.float64)

log_plot = np.zeros((256))

exp_plot = np.zeros((256))

si = 0.5

while(1):
	if(si > 2):
		break
	for i in range(r):
		for j in range(c):
			transform_g[i][j] = np.log(1 + ((np.exp(si))*a[i][j]))

	cv2.imwrite("1a_"+str(si)+".jpg",transform_g*20)

	im = Image.open("1a_"+str(si)+".jpg")

	im.show()

	si += 0.5


si = 0.5

while(1):
	if(si > 2):
		break
	for i in range(r):
		for j in range(c):
			z = a[i][j]
			z = z/20
			transform_g[i][j] = np.exp(si*z)
			print(transform_g[i][j])

	cv2.imwrite("1b_"+str(si)+".jpg",transform_g)

	im = Image.open("1b_"+str(si)+".jpg")

	im.show()

	si += 0.5


si = 0.5

for i in range(256):
	log_plot[i] = np.log(1 + ((np.exp(si))*i))

plt.figure(0)

plt.plot(log_plot,label = "si = 0.5")

plt.title("log_function")

plt.xlabel("i")

plt.ylabel("f")


si = 1

for i in range(256):
	log_plot[i] = np.log(1 + ((np.exp(si))*i))

plt.figure(0)

plt.plot(log_plot,label = "si = 1")


si = 1.5

for i in range(256):
	log_plot[i] = np.log(1 + ((np.exp(si))*i))

plt.figure(0)

plt.plot(log_plot, label = "si = 1.5")



si = 2

for i in range(256):
	log_plot[i] = np.log(1 + ((np.exp(si))*i))

plt.figure(0)

plt.plot(log_plot,label = "si = 2")

plt.savefig('1_log_plot.jpg')

im = Image.open("1_log_plot.jpg")

im.show()


si = 0.5

for i in range(256):
	x = i/255
	exp_plot[i] = np.exp(si*x)


plt.figure(1)

plt.plot(exp_plot,label = "si = 0.5")

plt.title("exp_plot")

plt.xlabel("i")

plt.ylabel("f")


si = 1

for i in range(256):
	x = i/255
	exp_plot[i] = np.exp(si*x)

plt.figure(1)

plt.plot(exp_plot,label = "si = 1")


si = 1.5

for i in range(256):
	x = i/255
	exp_plot[i] = np.exp(si*x)

plt.figure(1)

plt.plot(exp_plot, label = "si = 1.5")



si = 2

for i in range(256):
	x = i/255
	exp_plot[i] = np.exp(si*x)

plt.figure(1)

plt.plot(exp_plot,label = "si = 2")

plt.savefig('1_exp_plot.jpg')

im = Image.open("1_exp_plot.jpg")

im.show()
