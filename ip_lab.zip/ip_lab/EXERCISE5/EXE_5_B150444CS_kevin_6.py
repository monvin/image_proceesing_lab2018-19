import numpy as np
from pylab import *
import matplotlib.pyplot as plt
import cv2
A=cv2.imread("cameraman.tif",0)
a=A.shape[0]
b=3
C=np.zeros((a+b-1,a+b-1))
D=np.zeros((a+b-1,a+b-1))
def sobel(A):
	B=[[1,2,1],[0,0,0,],[-1,-2,-1]]
	for i in range(a+b-1):
		for j in range(a+b-1):
			l1min=max(i-b+1,0)
			l1max=min(i,a-1)
			l2min=max(j-b+1,0)
			l2max=min(j,a-1)
			for k in range(l1min,l1max+1):
				for l in range(l2min,l2max+1):
					C[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]

	B=[[-1,0,1],[-2,0,2],[-1,0,1]]
	for i in range(a+b-1):
		for j in range(a+b-1):
			l1min=max(i-b+1,0)
			l1max=min(i,a-1)
			l2min=max(j-b+1,0)
			l2max=min(j,a-1)
			for k in range(l1min,l1max+1):
				for l in range(l2min,l2max+1):
					D[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]
	subplot(121)
	plt.imshow(np.sqrt(np.square(C)+np.square(D)),cmap='gray'),plt.title("Sobel filter"),plt.xticks([]),plt.yticks([])
	plt.show()
	cv2.imwrite("6_sobel.jpg",np.sqrt(np.square(C)+np.square(D)))

def prewitt(A):
	B=[[1,0,-1],[1,0,-1],[1,0,-1]]
	for i in range(a+b-1):
		for j in range(a+b-1):
			l1min=max(i-b+1,0)
			l1max=min(i,a-1)
			l2min=max(j-b+1,0)
			l2max=min(j,a-1)
			for k in range(l1min,l1max+1):
				for l in range(l2min,l2max+1):
					C[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]

	B=[[1,1,1],[0,0,0],[-1,-1,-1]]
	for i in range(a+b-1):
		for j in range(a+b-1):
			l1min=max(i-b+1,0)
			l1max=min(i,a-1)
			l2min=max(j-b+1,0)
			l2max=min(j,a-1)
			for k in range(l1min,l1max+1):
				for l in range(l2min,l2max+1):
					D[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]
	subplot(121)
	plt.imshow(np.sqrt(np.square(C)+np.square(D)),cmap='gray'),plt.title("Prewitt filter"),plt.xticks([]),plt.yticks([])
	plt.show()
	cv2.imwrite("6_prewitt.jpg",np.sqrt(np.square(C)+np.square(D)))

def laplace(A):
	B=[[0,-1,0],[-1,4,-1],[0,-1,0]]
	for i in range(a+b-1):
		for j in range(a+b-1):
			l1min=max(i-b+1,0)
			l1max=min(i,a-1)
			l2min=max(j-b+1,0)
			l2max=min(j,a-1)
			for k in range(l1min,l1max+1):
				for l in range(l2min,l2max+1):
					C[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]
	subplot(121)
	plt.imshow(C,cmap='gray'),plt.title("Laplace filter"),plt.xticks([]),plt.yticks([])
	plt.show()
	cv2.imwrite("6_laplace.jpg",C)
prewitt(A)
sobel(A)
laplace(A)
