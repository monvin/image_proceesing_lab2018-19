import numpy as np
import cv2
import matplotlib.pyplot as plt
from pylab import *
img=cv2.imread("cameraman.tif",0)
n=img.shape[0]
new_img=np.zeros(img.shape,dtype=complex)
T_U_X=np.zeros(img.shape,dtype=complex)
#multiplication by -1^(x+y)
#for i in range(img.shape[0]):
#	for j in range(img.shape[1]):
#		new_img[i][j]=img[i][j]*np.power(-1,i+j)
#transformation matrix
for u in range(n):
	for x in range(n):
		T_U_X[u][x]=1/np.sqrt(n)*(np.cos(-2/n*np.pi*u*x)+1j*np.sin(-2/n*np.pi*u*x))
fourier=np.dot(T_U_X,np.dot(img,T_U_X))
duv=np.zeros(img.shape)
for i in range(n):
	for j in range(n):
		duv[i][j]=np.sqrt(i*i+j*j)
while True:
	cutoff=int(input("cutoff:"))
	def low():
		H=duv<=cutoff
		return H,"low pass"
	def butter():
		H=1/(1+(duv/cutoff)**(2*n))
		return H,"butterworth"
	def gauss():
		H=np.exp(-np.power(duv,2)/(2*np.power(cutoff,2)))
		return H,"gaussian"
	choice=int(input("1.low pass filter\n2.Butterworth\n3.Gaussian\n"))
	if choice==1:
		H,ftr=low()
	elif choice==2:
		H,ftr=butter()
	else:
		H,ftr=gauss()
	T_U_X_conj=np.conjugate(T_U_X)
	print(H)
	final=np.abs(np.dot(T_U_X_conj,(np.dot(np.multiply(H,fourier),T_U_X_conj))))
	subplot(121)
	plt.imshow(final,cmap='gray'),plt.title(ftr+" filter"),plt.xticks([]),plt.yticks([])
	cv2.imwrite("7_"+ftr+".jpg",final)
	plt.show()
