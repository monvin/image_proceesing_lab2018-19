import numpy as np
import cv2
import matplotlib.pyplot as plt
from pylab import *
img=cv2.imread("cameraman.tif",0)
n=img.shape[0]
def median(img,kernel_size):
	
	newimg=np.zeros((n,n))
	for i in range(n):
		for j in range(n):
			val=[]
			for p in range(kernel_size):
				for q in range(kernel_size):
					if i+p<n and i+p>=0 and j+q<n and j+q>=0:
						val.append(img[i+p][j+q])
			newimg[i][j] = np.median(val)
	subplot(121)
	plt.imshow(newimg,cmap='gray'),plt.title("Median filter"),plt.xticks([]),plt.yticks([])
	plt.show()
		
def mean(img,kernel_size):
	newimg=np.zeros((n,n))
	for i in range(n):
		for j in range(n):
			val=0
			for p in range(kernel_size):
				for q in range(kernel_size):
					if i+p<n and i+p>=0 and j+q<n and j+q>=0:
						val+=img[i+p][j+q]
			newimg[i][j] = val/np.square(kernel_size)
	subplot(121)
	plt.imshow(newimg,cmap='gray'),plt.title("Mean filter"),plt.xticks([]),plt.yticks([])
	plt.show()

def maximon(ing,kernel_size):
	newimg=np.zeros((n,n))
	for i in range(n):
		for j in range(n):
			val=[]
			for p in range(kernel_size):
				for q in range(kernel_size):
					if i+p<n and i+p>=0 and j+q<n and j+q>=0:
						val.append(img[i+p][j+q])
			newimg[i][j] = np.max(val)
	subplot(121)
	plt.imshow(newimg,cmap='gray'),plt.title("Max filter"),plt.xticks([]),plt.yticks([])
	plt.show()
	
def minimol(ing,kernel_size):
	newimg=np.zeros((n,n))
	for i in range(n):
		for j in range(n):
			val=[]
			for p in range(kernel_size):
				for q in range(kernel_size):
					if i+p<n and i+p>=0 and j+q<n and j+q>=0:
						val.append(img[i+p][j+q])
			newimg[i][j] = np.min(val)
	subplot(121)
	plt.imshow(newimg,cmap='gray'),plt.title("Min filter"),plt.xticks([]),plt.yticks([])
	plt.show()
	
kernel_size=int(input("Kernel size\n"))
while True:
	choice=int(input("1.median\n2.min\n3.max\n4.mean\n"))
	if choice==1:
		median(img,kernel_size)
	elif choice==2:
		minimol(img,kernel_size)
	elif choice==3:
		maximon(img,kernel_size)
	else:
		mean(img,kernel_size)
