import numpy
N=int(input("Size:"))
A=list(map(int,input().split(' ')))
B=list(map(int,input().split(' ')))
n=2*N-1
result=[0]*(n)	
for i in range(n):	
	kmin = max(i-N+1,0)
	kmax = min(N-1,i)
	for k in range(kmin,kmax+1):
		result[i]+=A[N-i-1+k]*B[k]
print(result)
	
