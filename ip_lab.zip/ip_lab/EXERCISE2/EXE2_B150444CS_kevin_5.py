import numpy as np
A=[[2,2,1],
   [1,2,-1],
   [3,3,3]]
B=[[1,1],
   [-1,-1]] 
a=int(len(A))
b=int(len(B))
C=np.zeros((a+b-1,a+b-1))
for i in range(a+b-1):
	for j in range(a+b-1):
		l1min=max(i-b+1,0)
		l1max=min(i,a-1)
		l2min=max(j-b+1,0)
		l2max=min(j,a-1)
		for k in range(l1min,l1max+1):
			for l in range(l2min,l2max+1):
				C[i][j]+=B[b-i-1+k][b-j-1+l]*A[k][l]
print(C)

D=np.zeros((a+b-1,a+b-1))
for i in range(a+b-1):
	for j in range(a+b-1):
		l1min=max(i-a+1,0)
		l1max=min(i,b-1)
		l2min=max(j-a+1,0)
		l2max=min(j,b-1)
		for k in range(l1min,l1max+1):
			for l in range(l2min,l2max+1):
				D[i][j]+=A[a-i-1+k][a-j-1+l]*B[k][l]
print(D)
