import numpy as np
import cv2
img=cv2.imread("img.tif",0)
avg=np.average(img)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if img[i][j]>avg:
			img[i][j]=255
		else:
			img[i][j]=0
cv2.imwrite("1.jpg",img)
