import numpy as np
A=[[1,-1,1,5,4],[1,2,-1,3,6],[1,1,1,0,7],[5,7,4,1,3],[1,5,4,2,0]]
B=[[2,2,2,3],[2,1,3,3],[2,2,1,2],[1,3,2,2]]
a=int(len(A))
b=int(len(B))
C=np.zeros((a+b-1,a+b-1))
for i in range(a+b-1):
	for j in range(a+b-1):
		l1min=max(i-b+1,0)
		l1max=min(i,a-1)
		l2min=max(j-b+1,0)
		l2max=min(j,a-1)
		for k in range(l1min,l1max+1):
			for l in range(l2min,l2max+1):
				C[i][j]+=A[k][l]*B[i-k][j-l]
print(C)
D=np.zeros((a+b-1,a+b-1))
for i in range(a+b-1):
	for j in range(a+b-1):
		l1min=max(i-a+1,0)
		l1max=min(i,b-1)
		l2min=max(j-a+1,0)
		l2max=min(j,b-1)
		for k in range(l1min,l1max+1):
			for l in range(l2min,l2max+1):
				D[i][j]+=B[k][l]*A[i-k][j-l]
print(D)
