import numpy as np
import cv2
#addition
img=cv2.imread("add.tif",0)
img1=cv2.imread("add1.tif",0)
SUM=np.zeros(img.shape)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if int(int(img[i][j])+int(img1[i][j]))>255:
			SUM[i][j]=255
		else:
			SUM[i][j]=img[i][j]+img1[i][j]
cv2.imshow("image",SUM)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("6_add.jpg",SUM)
#subtraction
img=cv2.imread("sub.tif",0)
cv2.imshow("image",img)
cv2.waitKey(0)
cv2.destroyAllWindows()
img1=cv2.imread("sub1.tif",0)
cv2.imshow("image",img1)
cv2.waitKey(0)
cv2.destroyAllWindows()
DIFF=np.zeros(img.shape)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if i<img1.shape[0] and j<img1.shape[1]:
			DIFF[i][j]=max(0,int(img[i][j])-int(img1[i][j]))
		else:
			DIFF[i][j]=img[i][j]
cv2.imshow("image",DIFF)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("6_sub.jpg",DIFF)
#multiplication
img=cv2.imread("add.tif",0)
cv2.imshow("image",img)
cv2.waitKey(0)
cv2.destroyAllWindows()
img1=np.zeros(img.shape)
c=float(input("Give constant:"))
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if int(int(img[i][j])*c)>255:
			img1[i][j]=255
		else:
			img1[i][j]=img[i][j]*c
cv2.imshow("image",img1)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("6_mult.jpg",img1)
#division
img=cv2.imread("add.tif",0)
cv2.imshow("image",img)
cv2.waitKey(0)
cv2.destroyAllWindows()
img1=np.zeros(img.shape)
c=float(input("Give constant:"))
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		if int(int(img[i][j])/c)>255:
			img1[i][j]=255
		else:
			img1[i][j]=img[i][j]/c
cv2.imshow("image",img1)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("6_div.jpg",img1)
