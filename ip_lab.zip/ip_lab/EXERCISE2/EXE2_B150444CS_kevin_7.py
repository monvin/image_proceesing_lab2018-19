import numpy as np
import cv2
img=cv2.imread("img.tif",0)
#and
img1=np.zeros(img.shape)
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		img1[i][j]=img[i][j]&img[i][j]
cv2.imshow("image",img1)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("7_and.jpg",img1)
#or
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		img1[i][j]=min(255,img[i][j]|img[i][j])
cv2.imshow("image",img1)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("7_or.jpg",img1)
#not
for i in range(img.shape[0]):
	for j in range(img.shape[1]):
		img1[i][j]=max(0,255-img[i][j])
cv2.imshow("image",img1)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("7_not.jpg",img1)
