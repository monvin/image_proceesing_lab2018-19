import math

import numpy as np

import matplotlib.pyplot as plt

import cv2

from pylab import *



def make_array(num,bits):
	arr=np.zeros((bits,),dtype=int)
	for i in range(bits,0,-1):
		arr[i-1]=num%2
		num=num/2
	return arr
			
img=cv2.imread('q1.jpg',0)
T=np.zeros(img.shape)
n=img.shape[0]
bits=int (math.log(n,2))

for u in range(n):
	b_n=make_array(u,bits)
	for x in range(n):
		if (np.sum(np.bitwise_and(make_array(x,bits), b_n)))%2==0:
			T[u][x]=1/np.sqrt(n)
		else:
			T[u][x]=-1/np.sqrt(n)
#hadamard transform
HT=np.dot(np.dot(T,img),T)
cv2.imwrite("1b_HT.jpg",HT)
#setting of left corner half transform coefficients to zero
altered_ht=HT
for u in range(n):
	for x in range(n-u):
		altered_ht[u][x]=0
#inverse HT
from_HT=np.dot(np.dot(T,altered_ht),T)
cv2.imwrite("1b_HT_altered.jpg",altered_ht)
cv2.imwrite("1b.jpg",from_HT)
fig=plt.figure(figsize=(10,10))
fig.add_subplot(321)
plt.imshow(img,cmap='gray'),plt.title('input image'), plt.xticks([]), plt.yticks([])
fig.add_subplot(322)
img=cv2.imread("1b_HT.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Hadamard Transform'),plt.xticks([]), plt.yticks([])	
img=cv2.imread("1b_HT_altered.jpg",0)
fig.add_subplot(323)
plt.imshow(img,cmap='gray'),plt.title('Altered Hadamard Transform'),plt.xticks([]), plt.yticks([])		
fig.add_subplot(324)
img=cv2.imread("1b.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Image from Hadamard'), plt.xticks([]), plt.yticks([])
plt.show()
