import numpy as np
import matplotlib.pyplot as plt
import cv2
from pylab import *
img=cv2.imread('q1.jpg',0)
T=np.zeros(img.shape,dtype=float64)
DCT=np.zeros(img.shape,dtype=float64)
n=img.shape[0]
#transformation matrix
for u in range(n):
	for x in range(n):
		if u==0:
			T[u][x]=np.sqrt(1/n)*(np.cos((2*x+1)*np.pi*u/(2*n)))
		else:
			T[u][x]=np.sqrt(2/n)*(np.cos((2*x+1)*np.pi*u/(2*n)))
#dct
DCT=np.dot(np.dot(T,img),np.transpose(T))
cv2.imwrite("1d_DCT.jpg",DCT)
#setting of left corner half transform coefficients to zero
altered_dct=DCT
for u in range(n):
	for x in range(n-u):
		altered_dct[u][x]=0
new_original=np.dot(np.dot(np.transpose(T),altered_dct),T)
cv2.imwrite("1d_altered_dct.jpg",altered_dct)
cv2.imwrite("1d.jpg",new_original)
fig=plt.figure(figsize=(10,10))
fig.add_subplot(321)
plt.imshow(img,cmap='gray'),plt.title('input image'), plt.xticks([]), plt.yticks([])
fig.add_subplot(322)
img=cv2.imread("1d_DCT.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('new cosine transform'), plt.xticks([]), plt.yticks([])
fig.add_subplot(323)
img=cv2.imread("1d_altered_dct.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Altered DCT'), plt.xticks([]), plt.yticks([])
fig.add_subplot(324)
img=cv2.imread("1d.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Image from DCT'), plt.xticks([]), plt.yticks([])
plt.show()
