import numpy as np

import matplotlib.pyplot as plt

import cv2

from pylab import *
import math

img=cv2.imread("q1.jpg",0)
n=img.shape[0]
avg=np.sum(img,0)/n
#Generating Covariance Matrix
#Covariance_mat=np.zeros((n,n))
#for i in range(n):
#	Covariance_mat+=np.dot((img[:,i]-avg),np.transpose(img[:,i]-avg))
#Covariance_mat/=n
#print(Covariance_mat-np.cov(img))
cov=np.cov(img)
eigen=np.linalg.eig(cov)
T=(eigen[1])
KLT=np.dot(np.dot(T,img),np.transpose(T))
cv2.imwrite("1e_KLT.jpg",KLT)
#Deleting transform coefficients
altered_klt=KLT
for u in range(n):
	for x in range(n-u):
		altered_klt[u][x]=0
cv2.imwrite("1e_KLT_altered.jpg",altered_klt)
from_klt=np.dot(np.dot(np.transpose(T),KLT),T)
cv2.imwrite("1e.jpg",from_klt)
fig=plt.figure(figsize=(10,10))
fig.add_subplot(321)
plt.imshow(img,cmap='gray'),plt.title('Input Image'), plt.xticks([]), plt.yticks([])
img=cv2.imread("1e_altered.jpg",0)
fig.add_subplot(322)
img=cv2.imread("1e_KLT.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('KLT'), plt.xticks([]), plt.yticks([])
fig.add_subplot(323)
img=cv2.imread("1e_KLT_altered.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Altered KLT'), plt.xticks([]), plt.yticks([])
fig.add_subplot(324)
img=cv2.imread("1e.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Image from KLT'), plt.xticks([]), plt.yticks([])
plt.show()
