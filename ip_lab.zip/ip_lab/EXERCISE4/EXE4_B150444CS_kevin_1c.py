import numpy as np

import matplotlib.pyplot as plt

import cv2

from pylab import *
import math

img=cv2.imread('q1.jpg',0)
HAAR=np.zeros(img.shape)

N=img.shape[0]
n=int (math.log(N,2))

K=np.zeros((N,2),dtype=float64)
K[0][0]=0
K[0][1]=0
K[1][0]=0
K[1][1]=1

for p in range (1,n):
	for q in range (1,pow(2,p)+1):
		k=pow(2,p)+q-1
		K[k][0]=p
		K[k][1]=q

for i in range (N):
	for j in range (N):
		if i==0:
			HAAR[i][j]=1/np.sqrt(N)
		else:
			q=K[i][1]
			p=K[i][0]
			if (q-1)/pow(2,p)<=j/N<(q-1/2)/pow(2,p):
				HAAR[i][j]=pow(2,p/2)/np.sqrt(N)
			elif (q-1/2)/pow(2,p)<=j/N<q/pow(2,p):
				HAAR[i][j]=-pow(2,p/2)/np.sqrt(N)
			else:		
				HAAR[i][j]=0
#haar transform
HAT=np.dot(np.dot(HAAR,img),np.transpose(HAAR))
cv2.imwrite("1c_HAT.jpg",HAT)
altered_hat=HAT
#removing some transform coefficients
for u in range(N):
	for x in range(N-u):
		altered_hat[u][x]=0
#Obtaining inverse
from_HAT=np.dot(np.dot(np.transpose(HAAR),HAT),HAAR)
cv2.imwrite("1c_HAT_altered.jpg",altered_hat)
cv2.imwrite("1c.jpg",from_HAT)

fig=plt.figure(figsize=(10,10))
fig.add_subplot(321)
plt.imshow(img,cmap='gray'),plt.title('Input Image'), plt.xticks([]), plt.yticks([])
img=cv2.imread("1c_altered.jpg",0)
fig.add_subplot(322)
img=cv2.imread("1c_HAT.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Haar Transform'), plt.xticks([]), plt.yticks([])
fig.add_subplot(323)
img=cv2.imread("1c_HAT_altered.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('ALtered Haar Transform'), plt.xticks([]), plt.yticks([])
fig.add_subplot(324)
img=cv2.imread("1c.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Image from Haar'), plt.xticks([]), plt.yticks([])
plt.show()

