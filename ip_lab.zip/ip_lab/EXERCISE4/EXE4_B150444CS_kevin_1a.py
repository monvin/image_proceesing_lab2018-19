import math

import numpy as np

import matplotlib.pyplot as plt

import cv2

from pylab import *



def make_array(num,bits):
	arr=np.zeros((bits,),dtype=int)
	for i in range(bits,0,-1):
		arr[i-1]=num%2
		num=num/2
	return arr
			
img=cv2.imread('q1.jpg',0)
T=np.zeros(img.shape)
n=img.shape[0]
bits=int (math.log(n,2))

for u in range(n):
	b_n=np.flipud(make_array(u,bits))
	for x in range(n):
		if (np.sum(np.bitwise_and(make_array(x,bits), b_n)))%2==0:
			T[u][x]=1/np.sqrt(n)
		else:
			T[u][x]=-1/np.sqrt(n)
#walsh transform
WT=np.dot(np.dot(T,img),T)
cv2.imwrite("1a_WT.jpg",WT)
#setting of left corner half transform coefficients to zero
altered_wt=WT
for u in range(n):
	for x in range(n-u):
		altered_wt[u][x]=0
#inverse WT
from_WT=np.dot(np.dot(T,altered_wt),T)
cv2.imwrite("1a_WT_altered.jpg",altered_wt)
cv2.imwrite("1a.jpg",from_WT)
fig=plt.figure(figsize=(10,10))
fig.add_subplot(321)
plt.imshow(img,cmap='gray'),plt.title('input image'), plt.xticks([]), plt.yticks([])
fig.add_subplot(322)
img=cv2.imread("1a_WT.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Walsh Transform'),plt.xticks([]), plt.yticks([])	
fig.add_subplot(323)
img=cv2.imread("1a_WT_altered.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Altered Walsh Transform'),plt.xticks([]),plt.yticks([])		
fig.add_subplot(324)
img=cv2.imread("1a.jpg",0)
plt.imshow(img,cmap='gray'),plt.title('Image from Walsh'), plt.xticks([]), plt.yticks([])
plt.show()
