#question 3
import numpy as np
import cv2
newimg=np.zeros((64,64))
for i in range(newimg.shape[0]):
    for j in range(newimg.shape[1]):
        newimg[i][j]=np.absolute(np.cos(np.sqrt((i*i+j*j))))*255
cv2.imwrite("3.jpg",newimg)
cv2.imshow("image",newimg)
cv2.waitKey(0)         
cv2.destroyAllWindows() 
