#question6
import numpy as np
import cv2
img6=cv2.imread('ss.jpg',0)
cv2.imshow("image",img6)
cv2.waitKey(0)         
cv2.destroyAllWindows() 
for i in range(img6.shape[0]):
    for j in range(img6.shape[1]):
        if img6[i][j] < 0.125*255:
            img6[i][j]=0
        elif img6[i][j] < 0.25*255:
            img6[i][j]=.125*255
        elif img6[i][j] < 0.375*255:
            img6[i][j]=.25*255
        elif img6[i][j]<0.5*255:
            img6[i][j]=0.375*255
        elif img6[i][j]<0.625*255:
            img6[i][j]=.5*255
        elif img6[i][j]<0.75*255:
            img6[i][j]=0.625*255
        elif img6[i][j]<.875*255:
            img6[i][j]=0.75*255
        elif img6[i][j] < 255:
            img6[i][j]=.875*255
        else :   
            img6[i][j]=255
cv2.imwrite('6.jpg',img6)
cv2.imshow("image",img6)
cv2.waitKey(0)         
cv2.destroyAllWindows()
