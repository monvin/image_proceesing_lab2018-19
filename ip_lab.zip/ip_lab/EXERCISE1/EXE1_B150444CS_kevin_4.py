#question4
import numpy as np
import cv2
img4=cv2.imread('im.tif',0)
cv2.imshow("image",img4)
cv2.waitKey(0)         
cv2.destroyAllWindows() 
for i in range(img4.shape[0]):
    for j in range(img4.shape[1]):
        if img4[i][j] < 0.25*255:
            img4[i][j]=0
        elif img4[i][j]<0.5*255:
            img4[i][j]=0.25*255
        elif img4[i][j]<0.75*255:
            img4[i][j]=0.5*255
        elif img4[i][j]<255:
            img4[i][j]=0.75*255
        else :   
            img4[i][j]=255
cv2.imwrite('4.tif',img4)
cv2.imshow("image",img4)
cv2.waitKey(0)         
cv2.destroyAllWindows()
