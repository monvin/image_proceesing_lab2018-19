#question5
import numpy as np
import cv2
img5=cv2.imread('ss.jpg',0)
max=np.amax(img5)
cv2.imshow("image",img5)
cv2.waitKey(0)         
cv2.destroyAllWindows() 
for i in range(img5.shape[0]):
    for j in range(img5.shape[1]):
        if img5[i][j] < 0.25*max:
            img5[i][j]=0
        elif img5[i][j]<0.5*max:
            img5[i][j]=0.25*max
        elif img5[i][j]<0.75*max:
            img5[i][j]=0.5*max
        elif img5[i][j]<max:
            img5[i][j]=0.75*max
        else :   
            img5[i][j]=255
cv2.imwrite('5.jpg',img5)
cv2.imshow("image",img5)
cv2.waitKey(0)         
cv2.destroyAllWindows()
