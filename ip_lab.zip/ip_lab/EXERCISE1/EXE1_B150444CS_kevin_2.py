#question2
import numpy as np
import cv2

img=cv2.imread("SECOND.jpg",0)
resolution=1024
v=1
while (resolution>16*v):
    simg=np.zeros((int(resolution/(v*2)),int(resolution/(v*2))))
    newimg=np.zeros((1024,1024))
    for i in range(int(resolution/(v*2))):
        for j in range(int(resolution/(v*2))):
            avg=int(int(img[2*i][2*j])+int(img[2*i+1][2*j+1])+int(img[2*i][2*j+1])+int(img[2*i+1][2*j]))/4
            simg[i][j]=avg
    cv2.imwrite("2." + str(resolution/(2*v)) + "x" + str(resolution/(2*v)) + ".jpg",simg)
    cv2.imshow("image",simg)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    for i in range(1024):
        for j in range(1024):
            newimg[i][j]=simg[int(i/(2*v))][int(j/(2*v))]
    cv2.imwrite("2.rev" + str(resolution/(2*v)) + "x" + str(resolution/(2*v)) + ".jpg",newimg)
    cv2.imshow("image",simg)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    v=v*2
    img=simg
