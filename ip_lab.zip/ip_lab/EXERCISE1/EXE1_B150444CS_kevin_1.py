#question1
import numpy as np
import cv2
img=cv2.imread("ss.jpg",0)
cv2.imshow("image",img)
cv2.imwrite("1.jpg",img)
cv2.waitKey(0)         
cv2.destroyAllWindows()  
print(np.amax(img))
print(np.amin(img))
